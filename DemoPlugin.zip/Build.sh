cd ./DemoPlugin/Linux_x86_64
g++ DemoForLinux.cpp -ljsoncpp -ldl -o DemoForLinux
./DemoForLinux







cd ./DemoPlugin/Windows_x86_64
g++ DemoForWindows.cpp -o DemoForWindows.exe -I"C:/jsoncpp" -ljsoncpp -ldl
./DemoForWindows.exe


